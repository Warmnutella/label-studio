import json
import pandas as pd

f = open("/Users/faithudoeyo/Documents/language_model/label-studio-converter/label_studio_converter/examples/project-7-at-2021-11-08-04-28-5259e82d.json")

hello = json.load(f)
#print(hello)

new_df = pd.DataFrame()
for i in hello:
    #print(i["Text"])
    full_text = i["Text"]
    parse_text = []
    parse_labels = []
    for j in i["label"]:
        #print(j["labels"])
        parse_text.append(j["text"])
        for k in j["labels"]:
            #print(k)
            parse_labels.append(k)

    #print(parse_text)
    #print(" ".join(parse_labels))
    #new_df = new_df.append({"Text": full_text, "parse_text": " ".join(parse_text), "parse_labels": " ".join(parse_labels)}, ignore_index=True)
    new_df = new_df.append({"parse_text": " ".join(parse_text), "parse_labels": " ".join(parse_labels)}, ignore_index=True)


new_df.to_csv("./new_df_20211107.tsv", sep="\t")

#print(new_df)
print(new_df["parse_text"])
print(new_df["parse_labels"])
